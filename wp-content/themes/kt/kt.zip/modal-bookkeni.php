 <div class="modal fade" id="BookKeni" tabindex="-1" role="dialog" aria-labelledby="BookKeni">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><img src="/wp-content/themes/kt/img/x.svg" alt="close icon"/></span></button>
        <h4 class="modal-title" id="myModalLabel">Book Keni</h4>
        <p><span class="separator"></span></p>
        <p>To book Keni, or find out availablity and pricing for your event, please fill out the form below.</p>
      </div>
      <div class="modal-body">
        <form id="book-form">
                <p class="sr-only"><label for="fname-book">First Name*</label></p>
                <p><input type="text" name="fname-book" id="fname-book" placeholder="First Name*"><label for="lname-book" class="sr-only">Last Name*</label><input type="text" name="lname-book" id="lname-book" placeholder="Last Name*"></p>
                <p><input type="text" name="company-book" id="company-book" placeholder="Company"><label for="dateloc-book" class="sr-only">Tentative Date &amp; Location</label><input type="text" name="dateloc-book" id="dateloc-book" placeholder="Tentative Date &amp; Location"></p>
                <p><input type="email" name="email-book" id="email-book" placeholder="E-mail address*"></p>
                <p><label for="subject-book" class="sr-only">Subject*</label><input type="text" name="subject-book" id="subject-book" placeholder="Subject*"></p>
                <p ><label for="message-book" id="modal-label-book">Message*</label></p>
                <p class="txt-area-p"><textarea rows="6" cols="59" name="message-book" id="message-book"  ></textarea></p>

                <p><input type="submit"></p>
                <p class="req">Required Field*</p>
            </form>
      </div>
     
    </div>
  </div>
</div>
    