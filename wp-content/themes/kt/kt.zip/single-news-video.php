<div class="embed-responsive-item">
<?php the_field('video_embed'); ?>
    </div></div>