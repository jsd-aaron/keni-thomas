<div class="modal fade lyricmodal" id="LyricsModal-give1" tabindex="-1" role="dialog" aria-labelledby="BookKeni">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><img src="/wp-content/themes/kt/img/x.svg" alt="close icon"/></span></button>
        <h4 class="modal-title" id="myModalLabel">Give It Away</h4>
        <p><span class="separator"></span></p>
        
      </div>
      <div class="modal-body">
        <p>No one raised their hand that day<br/>
When they asked for volunteers<br/>
He got picked out by default<br/>
            He was the only daddy there</p>
<p>
They said we know what you're thinking<br/>
Choose someone else instead<br/>
But this league is built on coaches<br/>
Who stood right there and said<br/>
</p>
<p>
Not me, not me, no way with this job of mine<br/>
I could never find the time not me, not me<br/>
The world becomes a better place when<br/>
Someone stands and leads the way<br/>
Steps forward when they'd rather say, not me<br/>
</p>
<p>
The judge says you're the oldest<br/>
May choose a legal guardian<br/>
I'm sorry that you lost your folks<br/>
But there's no next of kin</p>
      </div>
     <div class="down_arrow">scroll<a href="#scroll"><img src="/wp-content/themes/kt/img/littlearrow.svg" alt="down arrow" /></a></div>
    </div>
  </div>
</div>