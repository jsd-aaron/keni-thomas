<a href='<?php echo wp_get_attachment_image_src($id); ?>' target="_blank">
<?php the_post_thumbnail('news-hdr'); ?>
</a>