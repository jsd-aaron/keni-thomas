                    <div class="modal fade" id="topVidModal" tabindex="-1" role="dialog" aria-labelledby="topVidModal" aria-hidden="true">


     <div class="modal-header">
         <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><img src="wp-content/themes/kt/img/x.svg" alt="close icon"/></button>
     </div>
      <div class="modal-body">
          <iframe src="https://www.youtube.com/embed/q-F_pdtxtaI?rel=0" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true" target="_parent"></iframe>
        <div id="modal-video">
          
        </div>
      </div>
  </div>
