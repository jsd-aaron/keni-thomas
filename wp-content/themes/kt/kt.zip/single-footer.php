
   <div class="copyright">©Copyright 2015 Keni Thomas | Site Credit</div>
   
   
   
   

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="/wp-content/themes/kt/js/bootstrap.min.js"></script>

      
     
     <!-- modals -->
  
      

          <script type="text/javascript">
      
          $('#BookKeni1').on('shown.bs.modal', function () {
  $('#myInput').focus()
})
      
      </script> 

      
      <script type="text/javascript">
        
              $(function() {
	$(".mob-off").click(function() {
		$(".in").toggleClass("off");		
	});
});

      
      </script>
      


<?php wp_footer(); ?>

		<!-- analytics -->
		<script>
		(function(f,i,r,e,s,h,l){i['GoogleAnalyticsObject']=s;f[s]=f[s]||function(){
		(f[s].q=f[s].q||[]).push(arguments)},f[s].l=1*new Date();h=i.createElement(r),
		l=i.getElementsByTagName(r)[0];h.async=1;h.src=e;l.parentNode.insertBefore(h,l)
		})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
		ga('create', 'UA-XXXXXXXX-XX', 'yourdomain.com');
		ga('send', 'pageview');
		</script>



	</body>
</html>

		
